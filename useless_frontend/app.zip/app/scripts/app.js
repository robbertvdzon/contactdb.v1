'use strict';

/**
 * @ngdoc overview
 * @name mswFrontendApp
 * @description
 * # mswFrontendApp
 *
 * Main module of the application.
 */
angular
  .module('mswFrontendApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch'
  ])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/main.html',
        controller: 'MainCtrl'
      })
      .when('/game', {
        templateUrl: 'views/game.html',
        controller: 'GameCtrl'
      })
      .when('/team', {
        templateUrl: 'views/team.html',
        controller: 'TeamCtrl'
      })
      .when('/competition', {
        templateUrl: 'views/competition.html',
        controller: 'CompetitionCtrl'
      })
      .when('/login', {
        templateUrl: 'views/login.html',
        controller: 'LoginCtrl'
      })
      .when('/uitslagen', {
        templateUrl: 'views/uitslagen.html',
        controller: 'UitslagenCtrl'
      })
      .when('/speelschema', {
        templateUrl: 'views/speelschema.html',
        controller: 'SpeelschemaCtrl'
      })
      .otherwise({
        redirectTo: '/'
      });
  });
