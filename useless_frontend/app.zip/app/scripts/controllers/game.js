'use strict';

/**
 * @ngdoc function
 * @name mswFrontendApp.controller:GameCtrl
 * @description
 * # GameCtrl
 * Controller of the mswFrontendApp
 */
angular.module('mswFrontendApp')

    .controller('GameCtrl', ['$scope', '$rootScope', 'domainService', function ($scope, $rootScope, domainService) {
        $scope.var1 = {text: domainService.model.username};
        $scope.members = domainService.model.teammembers;

        $rootScope.$on('modelUpdated', function () {
            $scope.var1 = {text: domainService.model.username};
            $scope.members = domainService.model.teammembers;
        });

    }]);
