'use strict';

/**
 * @ngdoc function
 * @name mswFrontendApp.controller:SpeelschemaCtrl
 * @description
 * # SpeelschemaCtrl
 * Controller of the mswFrontendApp
 */
angular.module('mswFrontendApp')
  .controller('SpeelschemaCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
