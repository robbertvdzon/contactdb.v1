'use strict';

/**
 * @ngdoc function
 * @name mswFrontendApp.controller:TeamCtrl
 * @description
 * # TeamCtrl
 * Controller of the mswFrontendApp
 */
angular.module('mswFrontendApp')
  .controller('TeamCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
