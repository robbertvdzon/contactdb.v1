'use strict';

/**
 * @ngdoc function
 * @name mswFrontendApp.controller:UitslagenCtrl
 * @description
 * # UitslagenCtrl
 * Controller of the mswFrontendApp
 */
angular.module('mswFrontendApp')

    .controller('UitslagenCtrl', ['$scope', '$rootScope', 'domainService', function ($scope, $rootScope, domainService) {

        $scope.filter = -1;

        $scope.init = function () {
            $scope.loadUitslagen();
        };


        $rootScope.$on('modelUpdated', function () {
            $scope.loadUitslagen();
        });

        $scope.$watch('filter', function() {
            $scope.loadUitslagen();
        });


        $scope.filterOn2 = function () {
            $scope.filter = 1398;
        }

        $scope.clearfilter = function () {
            $scope.filter = -1;
        }

        $scope.loadUitslagen = function () {
            if(typeof domainService.model === 'undefined'){
                return;
            };
            $scope.teammembers = domainService.model.teammembers;
            $scope.uitslagen = [];
            var tmIndex = 0;
            var teammember;
            while (teammember = domainService.model.teammembers[tmIndex++]) {
//                console.log(teammember);
                var team = teammember.team;
                var compIndex = 0;
                var comp;
                while (comp = team.competitions[compIndex++]) {
//                    console.log(comp);
                    var gameIndex = 0;
                    var game;
                    if ($scope.filter == -1 || $scope.filter == comp.id) {
                        while (game = comp.games[gameIndex++]) {
//                            console.log(game);
                            $scope.uitslagen.push(game);
                        }
                    }
                }
            }
        };


        $scope.init();


    }])
;

